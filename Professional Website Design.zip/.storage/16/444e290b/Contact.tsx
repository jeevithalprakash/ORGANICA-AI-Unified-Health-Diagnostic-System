import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { useState } from 'react';
import { 
  Mail, 
  Phone, 
  MapPin, 
  Clock, 
  ArrowRight,
  Calendar,
  MessageSquare,
  Users,
  Zap,
  CheckCircle
} from 'lucide-react';

const contactInfo = [
  {
    icon: Mail,
    title: "Email Us",
    details: "hello@organica-ai.com",
    description: "Get in touch with our team"
  },
  {
    icon: Phone,
    title: "Call Us",
    details: "+1 (555) 123-4567",
    description: "Speak with our specialists"
  },
  {
    icon: MapPin,
    title: "Visit Us",
    details: "San Francisco, CA",
    description: "Our headquarters"
  },
  {
    icon: Clock,
    title: "Business Hours",
    details: "24/7 Support",
    description: "We're always here to help"
  }
];

const demoFeatures = [
  "Live platform demonstration",
  "Personalized use case discussion",
  "Integration planning session",
  "ROI analysis and pricing"
];

export default function Contact() {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    organization: '',
    role: '',
    message: ''
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate form submission
    console.log('Demo request submitted:', formData);
    setIsSubmitted(true);
    
    // Reset form after 3 seconds
    setTimeout(() => {
      setIsSubmitted(false);
      setFormData({
        firstName: '',
        lastName: '',
        email: '',
        organization: '',
        role: '',
        message: ''
      });
    }, 3000);
  };

  const handleLiveChat = () => {
    alert('Live chat feature would connect to customer support system');
  };

  const handlePartnerProgram = () => {
    alert('Partner program information would be displayed or redirect to partner portal');
  };

  const handleEmergencySupport = () => {
    window.open('tel:+15559114357', '_self');
  };

  const handleStartTrial = () => {
    alert('Free trial signup would redirect to registration page');
  };

  const handleDownloadBrochure = () => {
    alert('Brochure download would start automatically');
  };

  return (
    <section id="contact-section" className="py-20 bg-gradient-to-b from-white to-gray-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <Badge variant="outline" className="mb-4 text-purple-600 border-purple-200">
            Get Started
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Ready to Transform Healthcare?
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Join the revolution in AI-powered medical diagnostics. Schedule a demo today 
            and see how ORGANICA-AI can enhance your healthcare practice.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          {/* Demo Request Form */}
          <Card className="border-0 shadow-xl bg-white">
            <CardHeader className="pb-6">
              <div className="flex items-center space-x-3 mb-4">
                <Calendar className="text-blue-600" size={24} />
                <CardTitle className="text-2xl font-bold text-gray-900">
                  Schedule a Demo
                </CardTitle>
              </div>
              <CardDescription className="text-gray-600">
                Experience the power of AI-driven healthcare diagnostics firsthand
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {isSubmitted ? (
                <div className="text-center py-8">
                  <CheckCircle className="text-green-600 mx-auto mb-4" size={48} />
                  <h3 className="text-xl font-bold text-gray-900 mb-2">
                    Thank You!
                  </h3>
                  <p className="text-gray-600">
                    Your demo request has been submitted. Our team will contact you within 24 hours.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium text-gray-700 mb-2 block">
                        First Name *
                      </label>
                      <Input 
                        name="firstName"
                        value={formData.firstName}
                        onChange={handleInputChange}
                        placeholder="John" 
                        className="border-gray-200" 
                        required 
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-gray-700 mb-2 block">
                        Last Name *
                      </label>
                      <Input 
                        name="lastName"
                        value={formData.lastName}
                        onChange={handleInputChange}
                        placeholder="Doe" 
                        className="border-gray-200" 
                        required 
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-2 block">
                      Email Address *
                    </label>
                    <Input 
                      name="email"
                      type="email" 
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder="john.doe@hospital.com" 
                      className="border-gray-200" 
                      required 
                    />
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-2 block">
                      Organization
                    </label>
                    <Input 
                      name="organization"
                      value={formData.organization}
                      onChange={handleInputChange}
                      placeholder="Your Hospital/Clinic Name" 
                      className="border-gray-200" 
                    />
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-2 block">
                      Role/Title
                    </label>
                    <Input 
                      name="role"
                      value={formData.role}
                      onChange={handleInputChange}
                      placeholder="Chief Medical Officer" 
                      className="border-gray-200" 
                    />
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-2 block">
                      Message
                    </label>
                    <Textarea 
                      name="message"
                      value={formData.message}
                      onChange={handleInputChange}
                      placeholder="Tell us about your specific needs and use cases..."
                      className="border-gray-200 min-h-[100px]"
                    />
                  </div>

                  <div className="bg-blue-50 rounded-lg p-4">
                    <h4 className="font-semibold text-gray-900 mb-2 flex items-center">
                      <Zap className="text-blue-600 mr-2" size={16} />
                      What's Included in Your Demo:
                    </h4>
                    <ul className="space-y-1 text-sm text-gray-700">
                      {demoFeatures.map((feature, index) => (
                        <li key={index} className="flex items-center">
                          <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mr-2"></div>
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <Button 
                    type="submit"
                    className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white py-3"
                  >
                    Schedule Demo
                    <ArrowRight className="ml-2" size={16} />
                  </Button>
                </form>
              )}
            </CardContent>
          </Card>

          {/* Contact Information */}
          <div className="space-y-8">
            <Card className="border-0 shadow-xl bg-gradient-to-br from-blue-600 to-purple-600 text-white">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold mb-6">
                  Get in Touch
                </h3>
                <p className="text-blue-100 mb-8 leading-relaxed">
                  Our team of healthcare AI experts is ready to help you implement 
                  cutting-edge diagnostic solutions in your practice.
                </p>
                
                <div className="space-y-6">
                  {contactInfo.map((info, index) => (
                    <div key={index} className="flex items-start space-x-4">
                      <div className="bg-white/20 rounded-lg p-2">
                        <info.icon size={20} className="text-white" />
                      </div>
                      <div>
                        <div className="font-semibold text-white">
                          {info.title}
                        </div>
                        <div className="text-blue-100 font-medium">
                          {info.details}
                        </div>
                        <div className="text-blue-200 text-sm">
                          {info.description}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card 
                className="border-0 shadow-lg bg-white hover:shadow-xl transition-shadow duration-300 cursor-pointer group"
                onClick={handleLiveChat}
              >
                <CardContent className="p-6 text-center">
                  <MessageSquare className="text-green-600 mx-auto mb-3 group-hover:scale-110 transition-transform duration-300" size={32} />
                  <h4 className="font-bold text-gray-900 mb-2">
                    Live Chat
                  </h4>
                  <p className="text-sm text-gray-600">
                    Chat with our support team
                  </p>
                </CardContent>
              </Card>

              <Card 
                className="border-0 shadow-lg bg-white hover:shadow-xl transition-shadow duration-300 cursor-pointer group"
                onClick={handlePartnerProgram}
              >
                <CardContent className="p-6 text-center">
                  <Users className="text-blue-600 mx-auto mb-3 group-hover:scale-110 transition-transform duration-300" size={32} />
                  <h4 className="font-bold text-gray-900 mb-2">
                    Partner Program
                  </h4>
                  <p className="text-sm text-gray-600">
                    Join our partner network
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Emergency Contact */}
            <Card 
              className="border-0 shadow-lg bg-gradient-to-r from-red-50 to-orange-50 border-l-4 border-l-red-500 cursor-pointer hover:shadow-xl transition-shadow duration-300"
              onClick={handleEmergencySupport}
            >
              <CardContent className="p-6">
                <h4 className="font-bold text-gray-900 mb-2 flex items-center">
                  <Phone className="text-red-600 mr-2" size={16} />
                  Emergency Support
                </h4>
                <p className="text-gray-700 text-sm mb-2">
                  For critical system issues or urgent technical support:
                </p>
                <p className="font-semibold text-red-600">
                  +1 (555) 911-HELP
                </p>
                <p className="text-xs text-gray-500 mt-1">
                  Available 24/7 for enterprise customers
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center bg-gradient-to-r from-gray-900 to-blue-900 rounded-2xl p-8 text-white">
          <h3 className="text-3xl font-bold mb-4">
            Join the Future of Healthcare
          </h3>
          <p className="text-lg opacity-90 mb-6 max-w-2xl mx-auto">
            Be part of the AI revolution that's transforming medical diagnostics worldwide. 
            Your patients deserve the best care possible.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              variant="secondary" 
              className="bg-white text-blue-600 hover:bg-gray-100"
              onClick={handleStartTrial}
            >
              Start Free Trial
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-white text-white hover:bg-white hover:text-blue-600"
              onClick={handleDownloadBrochure}
            >
              Download Brochure
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}