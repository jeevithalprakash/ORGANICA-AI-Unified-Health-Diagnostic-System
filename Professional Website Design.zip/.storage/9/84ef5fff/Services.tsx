import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Stethoscope, 
  Monitor, 
  FileText, 
  Smartphone, 
  Microscope, 
  Target,
  UserCheck,
  ArrowRight,
  Clock,
  Award
} from 'lucide-react';

const services = [
  {
    icon: Monitor,
    title: "Multi-Organ System Analysis",
    description: "Comprehensive AI-powered analysis of brain, heart, lungs, kidneys, liver, and nervous system functioning.",
    features: [
      "Real-time organ function monitoring",
      "Cross-system correlation analysis", 
      "Predictive health modeling",
      "Automated anomaly detection"
    ],
    category: "Core Diagnostics",
    price: "Enterprise",
    color: "bg-blue-500"
  },
  {
    icon: Stethoscope,
    title: "Advanced Medical Imaging",
    description: "AI interpretation of X-rays, CT scans, and CCTA scans with 3D cardiac modeling capabilities.",
    features: [
      "Automated image analysis",
      "3D cardiac reconstruction",
      "Comparative imaging studies",
      "Radiologist-grade accuracy"
    ],
    category: "Radiology",
    price: "Professional",
    color: "bg-purple-500"
  },
  {
    icon: FileText,
    title: "Clinical Workflow Automation",
    description: "Streamlined patient documentation, summary generation, and clinical decision support.",
    features: [
      "Automated report generation",
      "Patient summary creation",
      "Clinical decision support",
      "EMR system integration"
    ],
    category: "Automation",
    price: "Standard",
    color: "bg-green-500"
  },
  {
    icon: Smartphone,
    title: "Mobile Health Screening",
    description: "Smartphone-based heart condition pre-screening using advanced sensor technology.",
    features: [
      "Heart rate variability analysis",
      "ECG signal processing",
      "Risk stratification",
      "Remote monitoring"
    ],
    category: "Mobile Health",
    price: "Basic",
    color: "bg-red-500"
  },
  {
    icon: Microscope,
    title: "Laboratory Data Analysis",
    description: "Comprehensive blood report analysis with pattern recognition and trend identification.",
    features: [
      "Multi-parameter analysis",
      "Trend identification",
      "Reference range optimization",
      "Predictive biomarkers"
    ],
    category: "Laboratory",
    price: "Professional",
    color: "bg-orange-500"
  },
  {
    icon: Target,
    title: "Early Cancer Detection",
    description: "AI-powered early cancer screening through multi-modal data analysis and risk assessment.",
    features: [
      "Multi-cancer screening",
      "Risk score calculation",
      "Early stage detection",
      "Personalized screening protocols"
    ],
    category: "Oncology",
    price: "Enterprise",
    color: "bg-pink-500"
  },
  {
    icon: UserCheck,
    title: "Personalized Health Coaching",
    description: "AI-driven personalized health recommendations and continuous wellness monitoring.",
    features: [
      "Personalized recommendations",
      "Lifestyle optimization",
      "Continuous monitoring",
      "Behavioral insights"
    ],
    category: "Wellness",
    price: "Standard",
    color: "bg-teal-500"
  }
];

export default function Services() {
  return (
    <section className="py-20 bg-gradient-to-b from-white to-gray-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <Badge variant="outline" className="mb-4 text-green-600 border-green-200">
            Our Services
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Comprehensive Healthcare Solutions
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            From diagnostic imaging to personalized health coaching, our AI-powered platform 
            offers a complete suite of healthcare solutions designed for modern medical practice.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {services.map((service, index) => (
            <Card key={index} className="group hover:shadow-2xl transition-all duration-300 border-0 shadow-lg bg-white relative overflow-hidden">
              {/* Background Gradient */}
              <div className="absolute inset-0 bg-gradient-to-br from-transparent to-gray-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              
              <CardHeader className="pb-4 relative z-10">
                <div className="flex items-center justify-between mb-4">
                  <div className={`p-3 rounded-xl ${service.color} text-white group-hover:scale-110 transition-transform duration-300`}>
                    <service.icon size={24} />
                  </div>
                  <div className="text-right">
                    <Badge variant="secondary" className="text-xs mb-1">
                      {service.category}
                    </Badge>
                    <div className="text-sm font-semibold text-blue-600">
                      {service.price}
                    </div>
                  </div>
                </div>
                <CardTitle className="text-xl font-bold text-gray-900 group-hover:text-blue-600 transition-colors">
                  {service.title}
                </CardTitle>
              </CardHeader>
              
              <CardContent className="relative z-10">
                <CardDescription className="text-gray-600 leading-relaxed mb-4">
                  {service.description}
                </CardDescription>
                
                <div className="space-y-2 mb-6">
                  {service.features.map((feature, idx) => (
                    <div key={idx} className="flex items-center text-sm text-gray-600">
                      <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mr-2 flex-shrink-0"></div>
                      {feature}
                    </div>
                  ))}
                </div>
                
                <Button 
                  variant="outline" 
                  className="w-full group-hover:bg-blue-600 group-hover:text-white group-hover:border-blue-600 transition-all duration-300"
                >
                  Learn More
                  <ArrowRight size={16} className="ml-2" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Service Benefits */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <div className="text-center">
            <div className="bg-blue-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              <Clock className="text-blue-600" size={32} />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">
              Rapid Results
            </h3>
            <p className="text-gray-600">
              Get diagnostic results in seconds, not hours, enabling faster clinical decisions.
            </p>
          </div>
          
          <div className="text-center">
            <div className="bg-green-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              <Award className="text-green-600" size={32} />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">
              Clinical Grade Accuracy
            </h3>
            <p className="text-gray-600">
              99.2% diagnostic accuracy validated by leading medical institutions worldwide.
            </p>
          </div>
          
          <div className="text-center">
            <div className="bg-purple-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              <UserCheck className="text-purple-600" size={32} />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">
              Personalized Care
            </h3>
            <p className="text-gray-600">
              Tailored recommendations based on individual patient profiles and medical history.
            </p>
          </div>
        </div>

        {/* CTA Section */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-8 text-white text-center">
          <h3 className="text-3xl font-bold mb-4">
            Ready to Transform Your Practice?
          </h3>
          <p className="text-lg opacity-90 mb-6 max-w-2xl mx-auto">
            Join thousands of healthcare professionals who trust ORGANICA-AI for accurate, 
            fast, and comprehensive diagnostic solutions.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary" className="bg-white text-blue-600 hover:bg-gray-100">
              Schedule Demo
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600">
              Contact Sales
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}