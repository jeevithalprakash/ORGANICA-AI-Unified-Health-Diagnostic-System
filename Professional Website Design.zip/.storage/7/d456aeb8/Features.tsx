import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Brain, 
  Heart, 
  Lungs, 
  Scan, 
  Workflow, 
  Smartphone, 
  TestTube, 
  Shield,
  Users
} from 'lucide-react';

const features = [
  {
    icon: Brain,
    title: "Multi-Organ Functioning Detection",
    description: "Advanced AI analysis of Brain, Heart, Lungs, Kidneys, Liver & Nervous System functioning with real-time monitoring and comprehensive health insights.",
    category: "Core Diagnostics",
    color: "bg-blue-500"
  },
  {
    icon: Scan,
    title: "Radiology & Interpretation",
    description: "Intelligent interpretation of X-rays, CT scans, and CCTA scans to assist early diagnosis with 3D cardiac modeling from medical imaging.",
    category: "Medical Imaging",
    color: "bg-purple-500"
  },
  {
    icon: Workflow,
    title: "Workflow Automation",
    description: "Automated preparation of patient summaries and comprehensive documentation with seamless integration into existing healthcare systems.",
    category: "Automation",
    color: "bg-green-500"
  },
  {
    icon: Smartphone,
    title: "Heart Condition Pre-Screening",
    description: "Revolutionary smartphone-based early heart risk detection using advanced sensors and AI algorithms for accessible cardiac monitoring.",
    category: "Mobile Health",
    color: "bg-red-500"
  },
  {
    icon: TestTube,
    title: "Blood Report Data Analysis",
    description: "Comprehensive analysis of blood report data with pattern recognition, trend analysis, and predictive health insights.",
    category: "Laboratory",
    color: "bg-orange-500"
  },
  {
    icon: Shield,
    title: "Early Cancer Detection",
    description: "Advanced AI algorithms for detecting early signs of cancer through multi-modal data analysis and risk assessment.",
    category: "Oncology",
    color: "bg-pink-500"
  },
  {
    icon: Users,
    title: "Personalized Health Coaching",
    description: "AI-driven personalized health recommendations, lifestyle coaching, and continuous monitoring for optimal wellness outcomes.",
    category: "Wellness",
    color: "bg-teal-500"
  }
];

export default function Features() {
  return (
    <section className="py-20 bg-gradient-to-b from-white to-gray-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <Badge variant="outline" className="mb-4 text-blue-600 border-blue-200">
            Core Features
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Comprehensive AI Health Diagnostics
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Our advanced AI platform combines cutting-edge technology with medical expertise 
            to deliver unprecedented diagnostic accuracy and personalized healthcare solutions.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg bg-white/80 backdrop-blur-sm hover:scale-105">
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between mb-4">
                  <div className={`p-3 rounded-xl ${feature.color} text-white group-hover:scale-110 transition-transform duration-300`}>
                    <feature.icon size={24} />
                  </div>
                  <Badge variant="secondary" className="text-xs">
                    {feature.category}
                  </Badge>
                </div>
                <CardTitle className="text-xl font-bold text-gray-900 group-hover:text-blue-600 transition-colors">
                  {feature.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-gray-600 leading-relaxed">
                  {feature.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Additional Info Section */}
        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-8 text-white">
            <h3 className="text-2xl font-bold mb-4">
              Revolutionizing Healthcare with AI
            </h3>
            <p className="text-lg opacity-90 max-w-2xl mx-auto">
              Our integrated approach combines multiple diagnostic modalities to provide 
              healthcare professionals with comprehensive, accurate, and actionable insights 
              for better patient outcomes.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}