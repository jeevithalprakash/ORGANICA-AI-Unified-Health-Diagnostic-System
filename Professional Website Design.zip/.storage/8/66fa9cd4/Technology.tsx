import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Cpu, 
  Database, 
  Shield, 
  Zap, 
  Globe, 
  Lock,
  CheckCircle,
  TrendingUp
} from 'lucide-react';

const technologies = [
  {
    icon: Cpu,
    title: "Advanced Machine Learning",
    description: "Deep neural networks trained on millions of medical images and patient data",
    progress: 95,
    color: "bg-blue-500"
  },
  {
    icon: Database,
    title: "Big Data Analytics",
    description: "Real-time processing of complex medical datasets with cloud infrastructure",
    progress: 92,
    color: "bg-green-500"
  },
  {
    icon: Shield,
    title: "HIPAA Compliant Security",
    description: "Enterprise-grade security with end-to-end encryption and data protection",
    progress: 100,
    color: "bg-purple-500"
  },
  {
    icon: Zap,
    title: "Real-time Processing",
    description: "Instant diagnostic results with sub-second response times",
    progress: 88,
    color: "bg-orange-500"
  }
];

const capabilities = [
  "Multi-modal medical imaging analysis",
  "Natural language processing for medical reports",
  "Predictive analytics for early disease detection",
  "Integration with existing EMR systems",
  "Mobile-first diagnostic tools",
  "Continuous learning and model improvement"
];

export default function Technology() {
  return (
    <section className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <Badge variant="outline" className="mb-4 text-purple-600 border-purple-200">
            Technology Stack
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Powered by Cutting-Edge AI
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Our platform leverages the latest advances in artificial intelligence, 
            machine learning, and medical imaging to deliver unparalleled diagnostic accuracy.
          </p>
        </div>

        {/* Technology Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {technologies.map((tech, index) => (
            <Card key={index} className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg bg-white">
              <CardHeader className="pb-4">
                <div className="flex items-center space-x-4 mb-4">
                  <div className={`p-3 rounded-xl ${tech.color} text-white group-hover:scale-110 transition-transform duration-300`}>
                    <tech.icon size={24} />
                  </div>
                  <div className="flex-1">
                    <CardTitle className="text-xl font-bold text-gray-900">
                      {tech.title}
                    </CardTitle>
                  </div>
                </div>
                <Progress value={tech.progress} className="h-2 mb-2" />
                <div className="text-sm text-gray-500 text-right">
                  {tech.progress}% Implementation
                </div>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-gray-600 leading-relaxed">
                  {tech.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Capabilities Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h3 className="text-3xl font-bold text-gray-900 mb-6">
              Core Capabilities
            </h3>
            <div className="space-y-4">
              {capabilities.map((capability, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <CheckCircle className="text-green-500 flex-shrink-0" size={20} />
                  <span className="text-gray-700">{capability}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl p-8">
            <div className="text-center mb-6">
              <TrendingUp className="mx-auto text-blue-600 mb-4" size={48} />
              <h4 className="text-2xl font-bold text-gray-900 mb-2">
                Performance Metrics
              </h4>
            </div>
            
            <div className="grid grid-cols-2 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600">99.2%</div>
                <div className="text-sm text-gray-600">Diagnostic Accuracy</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600">&lt;2s</div>
                <div className="text-sm text-gray-600">Processing Time</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-600">24/7</div>
                <div className="text-sm text-gray-600">Availability</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-orange-600">100%</div>
                <div className="text-sm text-gray-600">HIPAA Compliant</div>
              </div>
            </div>
          </div>
        </div>

        {/* Integration Section */}
        <div className="mt-16 bg-gradient-to-r from-gray-900 to-blue-900 rounded-2xl p-8 text-white text-center">
          <Globe className="mx-auto mb-4 text-blue-300" size={48} />
          <h3 className="text-2xl font-bold mb-4">
            Seamless Integration
          </h3>
          <p className="text-lg opacity-90 max-w-2xl mx-auto">
            Our platform integrates seamlessly with existing healthcare infrastructure, 
            EMR systems, and medical devices to enhance your current workflow without disruption.
          </p>
        </div>
      </div>
    </section>
  );
}