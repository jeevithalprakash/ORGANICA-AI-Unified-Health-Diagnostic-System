import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Target, 
  Eye, 
  Heart, 
  Users, 
  Globe, 
  Award,
  Lightbulb,
  Shield
} from 'lucide-react';

const values = [
  {
    icon: Target,
    title: "Precision",
    description: "Delivering accurate diagnostics through advanced AI algorithms and continuous learning."
  },
  {
    icon: Heart,
    title: "Compassion",
    description: "Putting patient care at the center of everything we do with empathy and understanding."
  },
  {
    icon: Lightbulb,
    title: "Innovation",
    description: "Pioneering breakthrough technologies that revolutionize healthcare delivery."
  },
  {
    icon: Shield,
    title: "Trust",
    description: "Maintaining the highest standards of security, privacy, and clinical reliability."
  }
];

const stats = [
  { number: "99.2%", label: "Diagnostic Accuracy" },
  { number: "500K+", label: "Patients Analyzed" },
  { number: "1000+", label: "Healthcare Partners" },
  { number: "50+", label: "Countries Served" }
];

export default function About() {
  return (
    <section className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <Badge variant="outline" className="mb-4 text-blue-600 border-blue-200">
            About Us
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Revolutionizing Healthcare with AI
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            ORGANICA-AI is at the forefront of medical innovation, developing cutting-edge 
            AI solutions that transform how healthcare professionals diagnose, treat, and care for patients.
          </p>
        </div>

        {/* Mission & Vision */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-50 to-purple-50">
            <CardContent className="p-8">
              <div className="flex items-center mb-6">
                <Target className="text-blue-600 mr-4" size={32} />
                <h3 className="text-2xl font-bold text-gray-900">Our Mission</h3>
              </div>
              <p className="text-gray-700 leading-relaxed text-lg">
                To democratize access to world-class medical diagnostics through AI, 
                enabling healthcare professionals to deliver faster, more accurate, 
                and personalized care to every patient, regardless of location or resources.
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-gradient-to-br from-green-50 to-teal-50">
            <CardContent className="p-8">
              <div className="flex items-center mb-6">
                <Eye className="text-green-600 mr-4" size={32} />
                <h3 className="text-2xl font-bold text-gray-900">Our Vision</h3>
              </div>
              <p className="text-gray-700 leading-relaxed text-lg">
                A world where AI-powered healthcare solutions eliminate diagnostic delays, 
                reduce medical errors, and provide every individual with personalized, 
                preventive care that extends and enhances quality of life.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Core Values */}
        <div className="mb-16">
          <h3 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Our Core Values
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <Card key={index} className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg bg-white text-center">
                <CardContent className="p-6">
                  <div className="bg-blue-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center group-hover:bg-blue-600 transition-colors duration-300">
                    <value.icon className="text-blue-600 group-hover:text-white transition-colors duration-300" size={32} />
                  </div>
                  <h4 className="text-xl font-bold text-gray-900 mb-3">
                    {value.title}
                  </h4>
                  <p className="text-gray-600 text-sm leading-relaxed">
                    {value.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Statistics */}
        <div className="bg-gradient-to-r from-gray-900 to-blue-900 rounded-2xl p-8 mb-16">
          <h3 className="text-3xl font-bold text-center text-white mb-12">
            Our Impact in Numbers
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl md:text-5xl font-bold text-white mb-2">
                  {stat.number}
                </div>
                <div className="text-blue-200 text-sm">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Company Story */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h3 className="text-3xl font-bold text-gray-900 mb-6">
              Our Story
            </h3>
            <div className="space-y-4 text-gray-700 leading-relaxed">
              <p>
                Founded by a team of visionary doctors, AI researchers, and healthcare innovators, 
                ORGANICA-AI emerged from a simple yet powerful observation: healthcare needed 
                a fundamental transformation in how medical data is analyzed and interpreted.
              </p>
              <p>
                Our journey began with the ambitious goal of creating an AI system that could 
                match and exceed human diagnostic capabilities across multiple organ systems. 
                Today, we're proud to offer a comprehensive platform that not only meets this 
                goal but continues to push the boundaries of what's possible in medical AI.
              </p>
              <p>
                With partnerships across 50+ countries and validation from leading medical 
                institutions, we're committed to making advanced healthcare accessible to all.
              </p>
            </div>
          </div>

          <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl p-8">
            <div className="space-y-6">
              <div className="flex items-center space-x-4">
                <Users className="text-blue-600" size={24} />
                <div>
                  <div className="font-semibold text-gray-900">Global Team</div>
                  <div className="text-sm text-gray-600">200+ experts across 15 countries</div>
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                <Globe className="text-green-600" size={24} />
                <div>
                  <div className="font-semibold text-gray-900">Worldwide Reach</div>
                  <div className="text-sm text-gray-600">Serving healthcare systems globally</div>
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                <Award className="text-purple-600" size={24} />
                <div>
                  <div className="font-semibold text-gray-900">Industry Recognition</div>
                  <div className="text-sm text-gray-600">Multiple healthcare innovation awards</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}