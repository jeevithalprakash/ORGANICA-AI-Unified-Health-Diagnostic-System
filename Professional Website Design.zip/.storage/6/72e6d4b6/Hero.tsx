import { Button } from '@/components/ui/button';
import { ArrowRight, Heart, Brain, Activity } from 'lucide-react';

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-white to-green-50 overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
      
      {/* Floating Medical Icons */}
      <div className="absolute top-20 left-10 text-blue-200 animate-pulse">
        <Heart size={40} />
      </div>
      <div className="absolute top-40 right-20 text-green-200 animate-bounce">
        <Brain size={35} />
      </div>
      <div className="absolute bottom-40 left-20 text-purple-200 animate-pulse">
        <Activity size={30} />
      </div>

      <div className="container mx-auto px-6 text-center relative z-10">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Main Heading */}
          <div className="space-y-4">
            <h1 className="text-6xl md:text-7xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-green-600 bg-clip-text text-transparent leading-tight">
              ORGANICA-AI
            </h1>
            <h2 className="text-3xl md:text-4xl font-semibold text-gray-700">
              VITAL UNITY-AI
            </h2>
          </div>

          {/* Tagline */}
          <p className="text-xl md:text-2xl text-gray-600 font-medium">
            An ambitious and visionary AI product
          </p>

          {/* Description */}
          <p className="text-lg md:text-xl text-gray-500 max-w-3xl mx-auto leading-relaxed">
            Revolutionary AI-powered health diagnostic system that detects multi-organ functioning, 
            interprets medical imaging, and provides personalized healthcare solutions with unprecedented accuracy.
          </p>

          {/* Key Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 my-12">
            <div className="bg-white/80 backdrop-blur-sm rounded-xl p-6 shadow-lg border border-gray-100">
              <div className="text-3xl font-bold text-blue-600">7+</div>
              <div className="text-gray-600">Core Diagnostic Features</div>
            </div>
            <div className="bg-white/80 backdrop-blur-sm rounded-xl p-6 shadow-lg border border-gray-100">
              <div className="text-3xl font-bold text-green-600">6</div>
              <div className="text-gray-600">Organ Systems Analyzed</div>
            </div>
            <div className="bg-white/80 backdrop-blur-sm rounded-xl p-6 shadow-lg border border-gray-100">
              <div className="text-3xl font-bold text-purple-600">AI</div>
              <div className="text-gray-600">Powered Diagnostics</div>
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-4 text-lg rounded-full shadow-lg hover:shadow-xl transition-all duration-300">
              Request Demo
              <ArrowRight className="ml-2" size={20} />
            </Button>
            <Button variant="outline" size="lg" className="border-2 border-gray-300 hover:border-blue-500 px-8 py-4 text-lg rounded-full transition-all duration-300">
              Learn More
            </Button>
          </div>

          {/* Trust Indicators */}
          <div className="pt-12">
            <p className="text-sm text-gray-400 mb-4">Trusted by healthcare professionals worldwide</p>
            <div className="flex justify-center items-center space-x-8 opacity-60">
              <div className="text-2xl font-bold text-gray-400">FDA</div>
              <div className="text-2xl font-bold text-gray-400">ISO</div>
              <div className="text-2xl font-bold text-gray-400">HIPAA</div>
              <div className="text-2xl font-bold text-gray-400">CE</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}